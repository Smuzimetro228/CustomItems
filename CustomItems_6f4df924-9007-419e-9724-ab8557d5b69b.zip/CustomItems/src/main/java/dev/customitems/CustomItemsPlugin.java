package dev.customitems;

import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.util.logging.Level;

public final class CustomItemsPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        ItemStorage storage = new ItemStorage(getDataFolder());
        try {
            storage.load();
        } catch (IOException | InvalidConfigurationException ex) {
            // Вимикаємось, щоб не перезаписати пошкоджений items.yml порожнім списком.
            getLogger().log(Level.SEVERE, "Cannot read items.yml - disabling plugin to keep your data safe", ex);
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        PluginCommand command = getCommand("citem");
        if (command == null) {
            getLogger().severe("Command 'citem' is missing in plugin.yml");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        CItemCommand handler = new CItemCommand(this, storage);
        command.setExecutor(handler);
        command.setTabCompleter(handler);

        getLogger().info("Loaded " + storage.size() + " custom item(s).");
    }
}
