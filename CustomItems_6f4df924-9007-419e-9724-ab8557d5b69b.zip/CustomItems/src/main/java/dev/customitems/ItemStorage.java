package dev.customitems;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Зберігає предмети у plugins/CustomItems/items.yml.
 *
 * Предмет серіалізується через ItemStack#serializeAsBytes() (повний NBT / data components
 * разом із DataVersion) і записується як Base64. Тому нічого не втрачається:
 * зачарування (в т.ч. кастомні), назва, lore, атрибути, PDC, вкладені предмети тощо.
 */
public final class ItemStorage {

    private final File file;

    // Назви нечутливі до регістру. Значення - Base64 серіалізованого предмета.
    // Предмет розкодовується лише в момент видачі, тому кастомні зачарування
    // з інших плагінів/датапаків не залежать від порядку завантаження плагінів.
    private final Map<String, String> items = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

    public ItemStorage(File dataFolder) {
        this.file = new File(dataFolder, "items.yml");
    }

    public void load() throws IOException, InvalidConfigurationException {
        items.clear();
        if (!file.isFile()) {
            return;
        }
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.load(file);
        ConfigurationSection section = yaml.getConfigurationSection("items");
        if (section == null) {
            return;
        }
        for (String name : section.getKeys(false)) {
            String data = section.getString(name);
            if (data != null && !data.isEmpty()) {
                items.put(name, data);
            }
        }
    }

    public boolean contains(String name) {
        return items.containsKey(name);
    }

    public int size() {
        return items.size();
    }

    public List<String> names() {
        return new ArrayList<>(items.keySet());
    }

    /** Повертає новий екземпляр збереженого предмета або null, якщо такої назви немає. */
    public ItemStack get(String name) {
        String data = items.get(name);
        if (data == null) {
            return null;
        }
        return ItemStack.deserializeBytes(Base64.getDecoder().decode(data));
    }

    public void put(String name, ItemStack item) throws IOException {
        items.put(name, Base64.getEncoder().encodeToString(item.serializeAsBytes()));
        save();
    }

    public boolean remove(String name) throws IOException {
        if (items.remove(name) == null) {
            return false;
        }
        save();
        return true;
    }

    private void save() throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<String, String> entry : items.entrySet()) {
            yaml.set("items." + entry.getKey(), entry.getValue());
        }
        File folder = file.getParentFile();
        if (folder != null) {
            folder.mkdirs();
        }
        yaml.save(file);
    }
}
