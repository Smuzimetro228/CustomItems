package dev.customitems;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.regex.Pattern;

public final class CItemCommand implements CommandExecutor, TabCompleter {

    private static final Pattern NAME_PATTERN = Pattern.compile("[\\p{L}\\p{N}_-]{1,32}");
    private static final List<String> SUBCOMMANDS = List.of("add", "give", "list", "remove");
    private static final Component PREFIX = Component.text("[CItem] ", NamedTextColor.GOLD);

    private final JavaPlugin plugin;
    private final ItemStorage storage;

    public CItemCommand(JavaPlugin plugin, ItemStorage storage) {
        this.plugin = plugin;
        this.storage = storage;
    }

    // ------------------------------------------------------------------ команди

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            usage(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "add" -> add(sender, args);
            case "give" -> give(sender, args);
            case "list" -> list(sender);
            case "remove" -> remove(sender, args);
            default -> usage(sender);
        }
        return true;
    }

    /** /citem add <назва> - зберігає предмет з основної руки. */
    private void add(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            error(sender, "Цю команду може виконати лише гравець (предмет береться з руки).");
            return;
        }
        if (args.length != 2) {
            error(sender, "Використання: /citem add <назва>");
            return;
        }
        String name = args[1];
        if (!NAME_PATTERN.matcher(name).matches()) {
            error(sender, "Назва: 1-32 символи - літери, цифри, _ або - (без пробілів).");
            return;
        }
        if (storage.contains(name)) {
            error(sender, "Предмет «" + name + "» уже є у списку. Спочатку: /citem remove " + name);
            return;
        }
        ItemStack inHand = player.getInventory().getItemInMainHand();
        if (inHand.getType().isAir()) {
            error(sender, "Візьміть предмет в основну руку.");
            return;
        }

        ItemStack copy = inHand.clone();
        copy.setAmount(1);
        try {
            storage.put(name, copy);
        } catch (IOException | RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Cannot save item '" + name + "'", ex);
            error(sender, "Не вдалося зберегти предмет (деталі в консолі).");
            return;
        }
        success(sender, "Предмет збережено як «" + name + "». Видати: /citem give " + name + " <гравець> [кількість]");
    }

    /** /citem give <назва> <гравець|@селектор> [кількість] */
    private void give(CommandSender sender, String[] args) {
        if (args.length < 3 || args.length > 4) {
            error(sender, "Використання: /citem give <назва> <гравець> [кількість]");
            return;
        }
        String name = args[1];

        ItemStack template;
        try {
            template = storage.get(name);
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Cannot read item '" + name + "'", ex);
            error(sender, "Не вдалося прочитати предмет «" + name + "» (деталі в консолі).");
            return;
        }
        if (template == null) {
            error(sender, "Предмет «" + name + "» не знайдено. Список: /citem list");
            return;
        }

        int amount = 1;
        if (args.length == 4) {
            try {
                amount = Integer.parseInt(args[3]);
            } catch (NumberFormatException ex) {
                error(sender, "Кількість має бути цілим числом.");
                return;
            }
        }
        int max = template.getMaxStackSize() * 100; // ліміт як у ванільного /give
        if (amount < 1 || amount > max) {
            error(sender, "Кількість має бути від 1 до " + max + ".");
            return;
        }

        List<Player> targets = findPlayers(sender, args[2]);
        if (targets.isEmpty()) {
            error(sender, "Гравця «" + args[2] + "» не знайдено (він має бути онлайн).");
            return;
        }

        for (Player target : targets) {
            giveTo(target, template, amount);
            if (!target.equals(sender)) {
                success(target, "Ви отримали «" + name + "» ×" + amount + ".");
            }
        }
        String to = targets.size() == 1
                ? "гравцю " + targets.get(0).getName()
                : "гравцям (" + targets.size() + ")";
        success(sender, "Видано «" + name + "» ×" + amount + " " + to + ".");
    }

    /** /citem list */
    private void list(CommandSender sender) {
        List<String> names = storage.names();
        if (names.isEmpty()) {
            send(sender, NamedTextColor.GRAY, "Список порожній. Додайте предмет: /citem add <назва>");
            return;
        }
        send(sender, NamedTextColor.YELLOW, "Предмети (" + names.size() + "): " + String.join(", ", names));
    }

    /** /citem remove <назва> */
    private void remove(CommandSender sender, String[] args) {
        if (args.length != 2) {
            error(sender, "Використання: /citem remove <назва>");
            return;
        }
        String name = args[1];
        try {
            if (storage.remove(name)) {
                success(sender, "Предмет «" + name + "» видалено зі списку.");
            } else {
                error(sender, "Предмет «" + name + "» не знайдено.");
            }
        } catch (IOException ex) {
            plugin.getLogger().log(Level.SEVERE, "Cannot save items.yml", ex);
            error(sender, "Не вдалося записати items.yml (деталі в консолі).");
        }
    }

    // ------------------------------------------------------------------ видача

    /** Ім'я гравця або селектор (@a, @p, @s, @r). Повертає лише онлайн-гравців. */
    private static List<Player> findPlayers(CommandSender sender, String input) {
        List<Player> result = new ArrayList<>();
        if (input.startsWith("@")) {
            try {
                for (Entity entity : Bukkit.selectEntities(sender, input)) {
                    if (entity instanceof Player player) {
                        result.add(player);
                    }
                }
            } catch (IllegalArgumentException ignored) {
                // некоректний селектор - повертаємо порожній список
            }
        } else {
            Player player = Bukkit.getPlayerExact(input);
            if (player != null) {
                result.add(player);
            }
        }
        return result;
    }

    private static void giveTo(Player target, ItemStack template, int amount) {
        int stackSize = template.getMaxStackSize();
        int remaining = amount;
        while (remaining > 0) {
            int chunk = Math.min(stackSize, remaining);
            remaining -= chunk;

            ItemStack stack = template.clone();
            stack.setAmount(chunk);

            // Те, що не влізло в інвентар, падає під ноги (як у ванільного /give).
            Map<Integer, ItemStack> leftover = target.getInventory().addItem(stack);
            for (ItemStack rest : leftover.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), rest);
            }
        }
    }

    // ------------------------------------------------------------------ Tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return filter(SUBCOMMANDS, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && (sub.equals("give") || sub.equals("remove"))) {
            return filter(storage.names(), args[1]);
        }
        if (sub.equals("give") && args.length == 3) {
            List<String> options = new ArrayList<>(List.of("@a", "@p", "@s", "@r"));
            for (Player player : Bukkit.getOnlinePlayers()) {
                options.add(player.getName());
            }
            return filter(options, args[2]);
        }
        if (sub.equals("give") && args.length == 4) {
            return filter(List.of("1", "16", "64"), args[3]);
        }
        return List.of();
    }

    private static List<String> filter(Collection<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) {
                result.add(option);
            }
        }
        return result;
    }

    // ------------------------------------------------------------------ повідомлення

    private static void usage(CommandSender sender) {
        send(sender, NamedTextColor.YELLOW, "/citem add <назва> - зберегти предмет з руки");
        send(sender, NamedTextColor.YELLOW, "/citem give <назва> <гравець> [кількість] - видати предмет");
        send(sender, NamedTextColor.YELLOW, "/citem list - список предметів");
        send(sender, NamedTextColor.YELLOW, "/citem remove <назва> - видалити зі списку");
    }

    private static void success(CommandSender sender, String text) {
        send(sender, NamedTextColor.GREEN, text);
    }

    private static void error(CommandSender sender, String text) {
        send(sender, NamedTextColor.RED, text);
    }

    private static void send(CommandSender sender, NamedTextColor color, String text) {
        sender.sendMessage(PREFIX.append(Component.text(text, color)));
    }
}
